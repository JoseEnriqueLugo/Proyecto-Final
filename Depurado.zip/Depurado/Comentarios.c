int Comentarios(){

	int conf, indice=0, resultadoCierre, otro;
	char nUsuario[50], numVuelo[50], caracter;
	FILE *Comentarios;


	do{
		CLEAR FLUSH
		p("\nProporcione su Nombre de Usuario: \t");
		s("%s", &nUsuario);
		FLUSH CLEAR
		p("Es %s su nombre de usuario?\n1)Si\n2)No\n", nUsuario);
		s("%i", &conf);
		FLUSH 
	}
	while(conf==2);

	do{	
		p("Proporcione el numero de vuelo del cual quiera hacer un comentario\t");
		s("%s", &numVuelo);
		FLUSH
		FILE*Comentarios = fopen ("Comentarios.txt", "a+");
		if(Comentarios==NULL){
			printf("\n\tHubo un problema disculpe las molestias");
		}else{
			fputs(nUsuario, Comentarios);
			fputc(':', Comentarios);
			fputs(numVuelo, Comentarios);
			fputc(';', Comentarios);
			FLUSH CLEAR
			p("Escriba su comentario:\n");
			while((caracter=getchar())!='\n' && indice<200)	{
				fputc(caracter,Comentarios);
				indice++;
			}			
			fputc('\n',Comentarios);
			FLUSH
			resultadoCierre=fclose(Comentarios);
			if(resultadoCierre==0){
				p("\n\n\tGracias por su comentario, seguiremos mejorando para brindarle un mejor servicio\n\n");
				getchar();
			}else{
				p("\n\n\tERROR al guardar su comentario, disculpe las molestias\n\n");
			}
			FLUSH CLEAR
			p("Desea Hacer un comentario sobre otro vuelo?\n1)Si\n2)No\n");
			s("%s", &otro);
		}
	}
	while(otro==1);
}
