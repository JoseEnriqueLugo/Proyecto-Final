int ImprimirVuelosUsuario(char codigo[], int opcion);
int CambiarAsientos(char asiento[]);

int ImprimirVuelosUsuario(char codigo[],int opcion){
	FILE *asientosVuelo;
	char nombreArchivo[100]={"./VuelosAsientos/Vuelo"};
	strcat(nombreArchivo,codigo);
	strcat(nombreArchivo,".txt");
	p("\nEntro a funcion y archivo %s**\n",nombreArchivo); getchar(); FLUSH
	asientosVuelo=fopen(nombreArchivo,"r");
	int posicion, indice, indiceR, indiceC, subcadena;
	char cadena[30], segmento[45][30];
	
	if(asientosVuelo!=NULL){
		fseek(asientosVuelo,0,SEEK_END);
		posicion=ftell(asientosVuelo);
		rewind(asientosVuelo);
		p("\nSe abrio vuelo\n"); getchar();
		while(feof(asientosVuelo)==0&&ftell(asientosVuelo)!=posicion){
	
			fgets(cadena,30,asientosVuelo);
			indiceR=0;
			indiceC=0;
			for(indice=0; indice<strlen(cadena); indice++){
				if(cadena[indice]==':'&&indice!=0){
					segmento[indiceR][indiceC]='\0';
					indiceR++;
					indiceC=0;
				}else{
					segmento[indiceR][indiceC]=cadena[indice];		
					indiceC++;
				}
			}		
			segmento[indiceR][indiceC-1]='\0';
			subcadena=indiceR;  
			for(indiceR=0; indiceR<subcadena; indiceR++){
				p("\nCadena %s**\n",segmento[indiceR]);
			}
			
		}

	}
	return 0;
}



int CambiarAsientos(char asiento[]){
	//Editara asientos
	FILE *asientosVuelo;
	char nombreArchivo[150]="./VuelosAsientos/Vuelo";
	asientosVuelo=fopen(nombreArchivo,"r");
	int posicion, indice, indiceR, indiceC, subcadena;
	char cadena[30], segmento[45][30];
	
	if(asientosVuelo!=NULL){
		fseek(asientosVuelo,0,SEEK_END);
		posicion=ftell(asientosVuelo);
		rewind(asientosVuelo);
		while(feof(asientosVuelo)==0&&ftell(asientosVuelo)!=posicion){
	
			fgets(cadena,30,asientosVuelo);
			indiceR=0;
			indiceC=0;
			for(indice=0; indice<strlen(cadena); indice++){
				if(cadena[indice]==':'&&indice!=0){
					segmento[indiceR][indiceC]='\0';
					indiceR++;
					indiceC=0;
				}else{
					segmento[indiceR][indiceC]=cadena[indice];		
					indiceC++;
				}
			}		
			segmento[indiceR][indiceC]='\0';
			subcadena=indiceR;
		}

	}
	return 0;

}

