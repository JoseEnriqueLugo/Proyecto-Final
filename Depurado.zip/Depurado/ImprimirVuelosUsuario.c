int ImprimirVuelosUsuario(char codigo[], int opcion);
int CambiarAsientos(char asiento[]);

int ImprimirVuelosUsuario(char codigo[],int opcion){
	FILE *asientosVuelo;
	char nombreArchivo[100]={"./VuelosAsientos/Vuelo"};
	strcat(nombreArchivo,codigo);
	strcat(nombreArchivo,".txt");
	asientosVuelo=fopen(nombreArchivo,"r");
	int posicion, indice, indiceR, indiceC, subcadena,hilera=0;
	char cadena[30], segmento[45][30], ocupado2[]={"X X"}, ocupado[]={"XX"}, *avion;

	avion=strstr(nombreArchivo,"A.txt");
	if(avion==NULL){		
		if(asientosVuelo!=NULL){
			p("\n\tAsientos del vuelo %s\n",codigo);
			p("\n\tAsientos disponibles en verde y ocupados en rojo\n");
			fseek(asientosVuelo,0,SEEK_END);
			posicion=ftell(asientosVuelo);
			rewind(asientosVuelo);
			while(feof(asientosVuelo)==0&&ftell(asientosVuelo)!=posicion){
	
				fgets(cadena,30,asientosVuelo);
				indiceR=0;
				indiceC=0;
				for(indice=0; indice<strlen(cadena); indice++){
					if(cadena[indice]==':'&&indice!=0){
						segmento[indiceR][indiceC]='\0';
						indiceR++;
						indiceC=0;
					}else{
						segmento[indiceR][indiceC]=cadena[indice];		
						indiceC++;
					}
				}		
				segmento[indiceR][indiceC-1]='\0';
				subcadena=indiceR;  
				p("\n\t");
				for(indiceR=0; indiceR<subcadena; indiceR++){
					if(hilera<10){
						if(strlen(segmento[indiceR])==3){
							if(strcmp(segmento[indiceR],ocupado2)==0){
								p(RED"[ %s  ]"RESET,segmento[indiceR]);
							}else{
								p(GRN"[ %s  ]"RESET,segmento[indiceR]);
							}
						}else{
							if(strcmp(segmento[indiceR],ocupado)==0){
								p(RED"[  %s  ]"RESET,segmento[indiceR]);
							}else{
								if(strcmp(segmento[indiceR],"pasillo")==0){
									p(CYN"[pasillo]");
								}else{
									p(GRN"[  %s  ]"RESET,segmento[indiceR]);
								}
							}
						}
					}else{
					
						if(strcmp(segmento[indiceR],ocupado)==0){
							p(RED"[%s]"RESET,segmento[indiceR]);
						}else{
							if(strcmp(segmento[indiceR],"pasillo")==0){
								p(CYN"[pasillo]");
							}else{
								p(GRN"[%s]"RESET,segmento[indiceR]);
							}
						}
					}									

				}
				hilera++;
			
			}

		}

	}else{	
		if(asientosVuelo!=NULL){
			fseek(asientosVuelo,0,SEEK_END);
			posicion=ftell(asientosVuelo);
			rewind(asientosVuelo);
			p("\n\tAsientos del vuelo %s\n",codigo);
			p("\n\tAsientos disponibles en verde y ocupados en rojo\n");
			while(feof(asientosVuelo)==0&&ftell(asientosVuelo)!=posicion){
	
				fgets(cadena,30,asientosVuelo);
				indiceR=0;
				indiceC=0;
				for(indice=0; indice<strlen(cadena); indice++){
					if(cadena[indice]==':'&&indice!=0){
						segmento[indiceR][indiceC]='\0';
						indiceR++;
						indiceC=0;
					}else{
						segmento[indiceR][indiceC]=cadena[indice];		
						indiceC++;
					}
				}		
				segmento[indiceR][indiceC-1]='\0';
				subcadena=indiceR;  
				p("\n\t");
				for(indiceR=0; indiceR<subcadena; indiceR++){
					if(strlen(segmento[indiceR])==2){
						if(strcmp(segmento[indiceR],ocupado)==0){
							p(RED"[ %s] "RESET,segmento[indiceR]);
						}else{
							p(GRN"[ %s] "RESET,segmento[indiceR]);
						}
					}else{
						if(strcmp(segmento[indiceR],ocupado2)==0){
							p(RED"[%s] "RESET,segmento[indiceR]);
						}else{
							if(strcmp(segmento[indiceR],"pasillo")==0){
								p(CYN"[pasillo] ");
							}else{
								p(GRN"[%s] "RESET,segmento[indiceR]);
							}
						}
					}				

				}
			
			}

		}
	}
	fclose(asientosVuelo);
	getchar(); FLUSH
	return 0;
}



int CambiarAsientos(char codigo[]){
	FILE *asientosVuelo;
	char nombreArchivo[100]={"./VuelosAsientos/Vuelo"};
	strcat(nombreArchivo,codigo);
	strcat(nombreArchivo,".txt");
	
	int posicion, indice, indiceR, indiceC, subcadena,hilera=0, cantidad=40, regreso=0;
	char cadena[30], segmento[45][30], ocupado2[]={"X X"}, ocupado[]={"XX"}, *avion, asientos[40][6], input[6];
	avion=strstr(nombreArchivo,"A.txt");
	
	while(cantidad==40){
		p("\nIngrese la cantidad de asientos por comprar: ");
		s(" %i",&cantidad); FLUSH
	}
	for(indice=0; indice<cantidad; indice++){
		p("\n\tIngrese el asiento %i: ",indice+1);
		s(" %[^\n]%*c",&asientos[indice]); FLUSH	
		strcpy(input,asientos[indice]); QUIT
		p("\n\tAsiento %i: %s**\n",indice,asientos[indice]);		
	}

	
	asientosVuelo=fopen(nombreArchivo,"r");
	if(avion==NULL){	
		if(asientosVuelo!=NULL){
			fseek(asientosVuelo,0,SEEK_END);
			posicion=ftell(asientosVuelo);
			rewind(asientosVuelo);
			p("\n\tEntro para B\n"); getchar();
			while(feof(asientosVuelo)==0&&ftell(asientosVuelo)!=posicion){
	
				fgets(cadena,30,asientosVuelo);
				indiceR=0;
				indiceC=0;
				for(indice=0; indice<strlen(cadena); indice++){
					if(cadena[indice]==':'&&indice!=0){
						segmento[indiceR][indiceC]='\0';
						indiceR++;
						indiceC=0;
					}else{
						segmento[indiceR][indiceC]=cadena[indice];		
						indiceC++;
					}
				}		
				segmento[indiceR][indiceC-1]='\0';
				subcadena=indiceR;  
				for(indiceR=0; indiceR<subcadena; indiceR++){
					for(indice=0; indice<cantidad; indice++){					
						if(hilera<10){
							if(strlen(segmento[indiceR])==3){
								if(strcmp(segmento[indiceR],asientos[indice])==0){
									p("\n\t1Se sustituye %s por XX\n",asientos[indice]);
								}else{
									p("\n\t2Se sustituye %s por XX\n",asientos[indice]);
								}
							}else{
								if(strcmp(segmento[indiceR],asientos[indice])==0){
									p("\n\t3Se sustituye %s por XX\n",asientos[indice]);
								}else{
									if(strcmp(segmento[indiceR],"pasillo")==0){
										p("\n\t4Se sustituye %s por XX\n",asientos[indice]);
									}else{
										p("\n\t5Se sustituye %s por XX\n",asientos[indice]);
									}
								}
							}
						}else{						
							if(strcmp(segmento[indiceR],asientos[indice])==0){
							}else{
								if(strcmp(segmento[indiceR],"pasillo")==0){
								}else{
								}
							}
						}	
					}									

				}
				hilera++;
			
			}

		}

	}else{	
		if(asientosVuelo!=NULL){
			fseek(asientosVuelo,0,SEEK_END);
			posicion=ftell(asientosVuelo);
			rewind(asientosVuelo);
			while(feof(asientosVuelo)==0&&ftell(asientosVuelo)!=posicion){
	
				fgets(cadena,30,asientosVuelo);
				indiceR=0;
				indiceC=0;
				for(indice=0; indice<strlen(cadena); indice++){
					if(cadena[indice]==':'&&indice!=0){
						segmento[indiceR][indiceC]='\0';
						indiceR++;
						indiceC=0;
					}else{
						segmento[indiceR][indiceC]=cadena[indice];		
						indiceC++;
					}
				}		
				segmento[indiceR][indiceC-1]='\0';
				subcadena=indiceR;  
				for(indiceR=0; indiceR<subcadena; indiceR++){
					if(strlen(segmento[indiceR])==2){
						if(strcmp(segmento[indiceR],asientos[indice])==0){
							
						}else{
							
						}
					}else{
						if(strcmp(segmento[indiceR],asientos[indice])==0){
							
						}else{
							if(strcmp(segmento[indiceR],"pasillo")==0){
								
							}else{
								
							}
						}
					}				

				}
			
			}

		}
	}
		
	getchar();
	return regreso;

}

