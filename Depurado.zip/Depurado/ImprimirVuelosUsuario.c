int ImprimirVuelosUsuario(char codigo[], int opcion);
int CambiarAsientos(char asiento[],char usuario[]);


int ImprimirVuelosUsuario(char codigo[],int opcion){
	FILE *asientosVuelo;
	char nombreArchivo[100]={"./VuelosAsientos/Vuelo"};
	strcat(nombreArchivo,codigo);
	strcat(nombreArchivo,".txt");
	asientosVuelo=fopen(nombreArchivo,"r");
	int posicion, indice, indiceR, indiceC, subcadena,hilera=0;
	char cadena[30], segmento[45][30], ocupado2[]={"X X"}, ocupado[]={"XX"}, *avion;

	//p("\nArchivo %s\n",nombreArchivo);
	avion=strstr(nombreArchivo,"A.txt");
	if(avion==NULL){		
		if(asientosVuelo!=NULL){
			p("\n\tAsientos del vuelo %s\n",codigo);
			p("\n\tAsientos disponibles en verde y ocupados en rojo\n");
			fseek(asientosVuelo,0,SEEK_END);
			posicion=ftell(asientosVuelo);
			rewind(asientosVuelo);
			while(feof(asientosVuelo)==0&&ftell(asientosVuelo)!=posicion){
	
				fgets(cadena,30,asientosVuelo);
				indiceR=0;
				indiceC=0;
				for(indice=0; indice<strlen(cadena); indice++){
					if(cadena[indice]==':'&&indice!=0){
						segmento[indiceR][indiceC]='\0';
						indiceR++;
						indiceC=0;
					}else{
						segmento[indiceR][indiceC]=cadena[indice];		
						indiceC++;
					}
				}		
				segmento[indiceR][indiceC-1]='\0';
				subcadena=indiceR;  
				p("\n\t");
				for(indiceR=0; indiceR<subcadena; indiceR++){
					if(hilera<10){
						if(strlen(segmento[indiceR])==3){
							if(strcmp(segmento[indiceR],ocupado2)==0){
								p(RED"[ %s  ]"RESET,segmento[indiceR]);
							}else{
								p(GRN"[ %s  ]"RESET,segmento[indiceR]);
							}
						}else{
							if(strcmp(segmento[indiceR],ocupado)==0){
								p(RED"[  %s  ]"RESET,segmento[indiceR]);
							}else{
								if(strcmp(segmento[indiceR],"pasillo")==0){
									p(CYN"[pasillo]");
								}else{
									p(GRN"[  %s  ]"RESET,segmento[indiceR]);
								}
							}
						}
					}else{
					
						if(strcmp(segmento[indiceR],ocupado)==0){
							p(RED"[%s]"RESET,segmento[indiceR]);
						}else{
							if(strcmp(segmento[indiceR],"pasillo")==0){
								p(CYN"[pasillo]");
							}else{
								p(GRN"[%s]"RESET,segmento[indiceR]);
							}
						}
					}									

				}
				hilera++;
			
			}

		}

	}else{	
		if(asientosVuelo!=NULL){
			fseek(asientosVuelo,0,SEEK_END);
			posicion=ftell(asientosVuelo);
			rewind(asientosVuelo);
			p("\n\tAsientos del vuelo %s\n",codigo);
			p("\n\tAsientos disponibles en verde y ocupados en rojo\n");
			while(feof(asientosVuelo)==0&&ftell(asientosVuelo)!=posicion){
	
				fgets(cadena,30,asientosVuelo);
				indiceR=0;
				indiceC=0;
				for(indice=0; indice<strlen(cadena); indice++){
					if(cadena[indice]==':'&&indice!=0){
						segmento[indiceR][indiceC]='\0';
						indiceR++;
						indiceC=0;
					}else{
						segmento[indiceR][indiceC]=cadena[indice];		
						indiceC++;
					}
				}		
				segmento[indiceR][indiceC-1]='\0';
				subcadena=indiceR;  
				p("\n\t");
				for(indiceR=0; indiceR<subcadena; indiceR++){
					if(strlen(segmento[indiceR])==2){
						if(strcmp(segmento[indiceR],ocupado)==0){
							p(RED"[ %s] "RESET,segmento[indiceR]);
						}else{
							p(GRN"[ %s] "RESET,segmento[indiceR]);
						}
					}else{
						if(strcmp(segmento[indiceR],ocupado2)==0){
							p(RED"[%s] "RESET,segmento[indiceR]);
						}else{
							if(strcmp(segmento[indiceR],"pasillo")==0){
								p(CYN"[pasillo] ");
							}else{
								p(GRN"[%s] "RESET,segmento[indiceR]);
							}
						}
					}				

				}
			
			}

		}
	}
	fclose(asientosVuelo);
	getchar(); FLUSH
	return 0;
}



int CambiarAsientos(char codigo[],char usuario[]){
	FILE *asientosVuelo;
	FILE *copia;
	char nombreArchivo[100]={"./VuelosAsientos/Vuelo"};
	strcat(nombreArchivo,codigo);
	strcat(nombreArchivo,".txt");
	
	int posicion, indice, indiceR, indiceC, subcadena,hilera=0, cantidad=40, regreso=0, salir=0, opcion=0, repetir=0, similitud=0;
	int error=0;
	char cadena[30], segmento[45][30], ocupado2[]={"X X"}, ocupado[]={"XX"}, *avion, asientos[40][6], input[6];
	avion=strstr(nombreArchivo,"A.txt");
	asientosVuelo=fopen(nombreArchivo,"r");
	copia=fopen("Copia.txt","w+");

	while(salir==0){
		while(repetir==0){
			while(cantidad==40){
				p("\nIngrese la cantidad de asientos por comprar: ");
				s(" %i",&cantidad); FLUSH
			}
			for(indice=0; indice<cantidad; indice++){
				p("\n\tIngrese el asiento %i: ",indice+1);
				s(" %[^\n]%*c",&asientos[indice]); FLUSH	
				strcpy(input,asientos[indice]); QUIT		
			}
			CLEAR
			opcion=0;
			while(opcion!=1&&opcion!=2&&opcion!=3){
				p("\n\tConfirmacionde compra\n");
				for(indice=0; indice<cantidad; indice++){
				p("\n\tSe comprara asiento:"CYN" %s\n"RESET,asientos[indice]);
				}
				p("\n\n\t\t1. Confirmar boletos\n");
				p("\n\t\t2. Cambiar boletos\n");
				p("\n\t\t3. Cancelar compra\n");
				s(" %i",&opcion); FLUSH CLEAR
				if(opcion==2){
					repetir=0;
				}else{
					repetir=1;
				}
			}
		}
		if(opcion==3){
			break;
		}
		
		if(avion==NULL){	
			if(asientosVuelo!=NULL){
				fseek(asientosVuelo,0,SEEK_END);
				posicion=ftell(asientosVuelo);
				rewind(asientosVuelo);
				while(feof(asientosVuelo)==0&&ftell(asientosVuelo)!=posicion){
		
					fgets(cadena,30,asientosVuelo);
					indiceR=0;
					indiceC=0;
					for(indice=0; indice<strlen(cadena); indice++){
						if(cadena[indice]==':'&&indice!=0){
							segmento[indiceR][indiceC]='\0';
							indiceR++;
							indiceC=0;
						}else{
							segmento[indiceR][indiceC]=cadena[indice];		
							indiceC++;
						}
					}		
					segmento[indiceR][indiceC-1]='\0';
					subcadena=indiceR;
					indice=0;
					for(indiceR=0; indiceR<subcadena; indiceR++){
						similitud=0;
						for(indice=0; indice<cantidad; indice++){
							if(strcmp(segmento[indiceR],asientos[indice])==0){
								similitud=1;
								error++;
							}	
						}
						if(similitud==1){
							if(strlen(segmento[indiceR])==2){
								fprintf(copia,"%s:",ocupado);
							}else{
								fprintf(copia,"%s:",ocupado2);
							}
						}else{
							fprintf(copia,"%s:",segmento[indiceR]);
						}
							
					}
					fprintf(copia,"\n");	
					salir=1;
				
				}
	
		}	

		}else{	
			if(asientosVuelo!=NULL){
				fseek(asientosVuelo,0,SEEK_END);
				posicion=ftell(asientosVuelo);
				rewind(asientosVuelo);
				while(feof(asientosVuelo)==0&&ftell(asientosVuelo)!=posicion){
		
					fgets(cadena,30,asientosVuelo);
					indiceR=0;
					indiceC=0;
					for(indice=0; indice<strlen(cadena); indice++){
						if(cadena[indice]==':'&&indice!=0){
							segmento[indiceR][indiceC]='\0';
							indiceR++;
							indiceC=0;
						}else{
							segmento[indiceR][indiceC]=cadena[indice];		
							indiceC++;
						}
					}		
					segmento[indiceR][indiceC-1]='\0';
					subcadena=indiceR; 
					for(indiceR=0; indiceR<subcadena; indiceR++){
						similitud=0;
						for(indice=0; indice<cantidad; indice++){
							if(strcmp(segmento[indiceR],asientos[indice])==0){
								similitud=1;
								error++;
							}	
						}
						if(similitud==1){
							if(strlen(segmento[indiceR])==2){
								fprintf(copia,"%s:",ocupado);
							}else{
								fprintf(copia,"%s:",ocupado2);
							}
						}else{
							fprintf(copia,"%s:",segmento[indiceR]);
						}
									
	
					}
					fprintf(copia,"\n");
				
				}
	
			}
		}salir=1;
	}	
	fclose(copia);
	fclose(asientosVuelo);
	if(error<cantidad){
		p("\nNo hay similitud con los boletos, intente nuevamente\n");
		regreso=0; 
	}else{
		nombreArchivo[0]='\0';
		strcat(nombreArchivo, "rm ./VuelosAsientos/Vuelo");
		strcat(nombreArchivo,codigo);
		strcat(nombreArchivo,".txt");
		system(nombreArchivo);
		nombreArchivo[0]='\0';
		strcat(nombreArchivo,"mv ./Copia.txt ./VuelosAsientos/Vuelo");
		strcat(nombreArchivo,codigo);
		strcat(nombreArchivo,".txt");
		system(nombreArchivo);
		for(indice=0; indice<cantidad; indice++){	
			RegistrarVuelo(usuario,codigo,asientos[indice],indice);	
		}
		asientos[indice][0]='\0';
		RegistrarVuelo(usuario,codigo,asientos[indice],indice);	
		regreso=1;
	}
	getchar();
	return regreso;

}

