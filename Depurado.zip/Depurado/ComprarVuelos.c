int ComprarVuelos();
int ImprimirVueloSeleccionado(char salida[],char llegada[]);
int UsuarioInfoGuardar(char nickname[],char contrasenia[],int vuelo);
char *RegresarCadena(char arreglo[],int vuelo);
//int RegistrarVuelo(int vuelo,char codigo[],int menu);


int ComprarVuelos(){
	FILE *listaVuelos;

	char aeropuertoSalida[100], aeropuertoLlegada[100];
	int resultadoComprobacion=0, resultadoVuelos, opcion=0, opcionValida=0, regresoCompra=0;

	CLEAR	
	p("\n\tBienvenido al sistema de compra\n");
	p("\n\tA continuacion se presentaran los vuelos disponibles\n");
	getchar(); FLUSH
//	system("gnome-terminal -x sh -c ./OrdenarVuelos & disown"); CLEAR
	
	p("\n\tPara conocer vuelos, ingrese aeropuerto de salida:\n\n\t");
	s(" %[^\n]%*c",&aeropuertoSalida); FLUSH
	p("\n\tIngresar aeropuerto de llegada\n\n\t");
	s(" %[^\n]%*c",&aeropuertoLlegada); FLUSH
	resultadoComprobacion=FuncionComprobarVuelo(aeropuertoSalida,aeropuertoLlegada);
		if(resultadoComprobacion!=1){
			p("\n\tEl aeropuerto de llegada ingresado no existe\n");
			p("\n\tIntente de nuevo\n");
			getchar(); FLUSH CLEAR		
		}else{
			resultadoVuelos=ImprimirVueloSeleccionado(aeropuertoSalida,aeropuertoLlegada);
		}
	

	
	return 0;
}


int ImprimirVueloSeleccionado(char salida[],char llegada[]){


	FILE *archivo;
	archivo=fopen("CodigoVuelos.txt","r");
	int posicion, indice, indiceR, indiceC, contador=0, menu=1, opcionValida=0, opcion=0, repetir=0, regresoCompra, salir=0;
	int comprobacion=2, vuelo=1;
	char cadena[200], segmento[100][100], usuario[100], input[50], password[50], arreglo[50][50];

	CLEAR
	while(repetir==0){
		contador=0;
		if(archivo!=NULL){
			fseek(archivo,0,SEEK_END);
			posicion=ftell(archivo);
			rewind(archivo);
			while(feof(archivo)==0&&ftell(archivo)!=posicion){
			
				fgets(cadena,200,archivo);
				indiceR=0; indiceC=0;
				for(indice=0; indice<strlen(cadena);indice++){
					if(cadena[indice]=='-'&&indice!=0){
						segmento[indiceR][indiceC]='\0';
						indiceR++;
						indiceC=0;
					}else{
						segmento[indiceR][indiceC]=cadena[indice];
						indiceC++;
					}	
				}
				segmento[indiceR][indiceC-1]='\0';
				vuelo=-1;
				if(strcmp(segmento[1],salida)==0&&strcmp(segmento[2],llegada)==0){
				
					p(GRN"\n\tOpcion %i"RESET" %s",contador+1,segmento[1]);
					p(" - %s\n"RESET,segmento[2]);
					p(CYN"\n\t\tDia de salida: "RESET" %s\n",segmento[3]);
					p(CYN"\n\t\tHora de salida: "RESET" %s\n",segmento[4]);
					p(CYN"\n\t\tDia de llegada: "RESET"%s\n",segmento[5]);
					p(CYN"\n\t\tHora de llegada; "RESET"%s\n",segmento[6]);
					p(CYN"\n\t\tPrecio: "RESET"%s\n",segmento[7]);
					p(CYN"\n\t\tCodigo de vuelo: "RESET"%s\n",segmento[0]);
					UsuarioInfoGuardar(segmento[0],segmento[1],vuelo);
					contador++;
				}
			}
			getchar(); FLUSH CLEAR	
			p("\nIndique la opcion a realizar\n");
			opcionValida=0;
			while(opcionValida==0){
				
				for(opcion=1; opcion<=contador; opcion++){
					p("\n\t\t%i.Comprar boletos para opcion %i de vuelo.\n",opcion,opcion);
				}
				p("\n\t\t%i.Volver a ver lista\n",opcion);
				p("\n\t\t%i.Cancelar compra\n",opcion+1);
				s(" %i",&opcion); FLUSH
				if(opcion>=1&&opcion<=contador+2){
					opcionValida=1;
				}
				CLEAR
				p("\nIndique la opcion a realizar\n");
			}
			if(opcion==contador+1){
				repetir=0;
			}else{
				if(opcion==contador+2){
					repetir=1;
				}else{							
					vuelo=opcion;		
					opcion=0;
					while(opcion!=1&&opcion!=2&&opcion!=3){
						p("\n\tLa opcion seleccionada fue opcion %i\n",vuelo);
						p("\n\t\t1. Continuar con compra\n");
						p("\n\t\t2. Cancelar compra\n");
						p("\n\t\t3. Volver a ver lista\n\n\t");
						s(" %i",&opcion); FLUSH CLEAR
					}
					if(opcion==1){
						p("\n\tPara comfirmar la compra de los boletos\n");
						p("\n\tIngresar nickname: ");
						s(" %[^\n]%*c",&usuario); FLUSH
						strcpy(input,usuario); QUIT
						p("\n\tIngresar contrasenia: ");
						s(" %[^\n]%*c",&password); FLUSH
						strcpy(input, password); QUIT
						comprobacion=UsuarioInfoGuardar(usuario,password,vuelo);
					
						if(comprobacion==1){
							p("\n\tA continuacion se presenta lista de asientos disponibles");
							contador=0;	
							salida=RegresarCadena(arreglo[contador],contador);
							p("\nSe regreso codigo %s**\n",salida); FLUSH getchar();
							ImprimirVuelosUsuario(salida, vuelo);
							
						}else{
							p("\n\tEl usuario o contrasenia ingresadas son erroneas, intente de nuevo\n");
							getchar(); FLUSH CLEAR
							opcion=0;
							while(opcion!=1&&opcion!=2){
								p("\n\t\t1. Continuar con compra\n");
								p("\n\t\t2. Cancelar compra\n\n\t");
								s(" %i",&opcion); FLUSH CLEAR
							}
							if(opcion==2){
								salir=1;
								repetir=1;
							}
						}
					}else{
						if(opcion==3){
							repetir=0;
						}else{
							repetir=1; CLEAR
						}
					}					
				}
				
			}
			
			CLEAR
		}	
			
	}
	return contador;
}

int UsuarioInfoGuardar(char arreglo1[],char arreglo2[],int vuelo){

	static char nickname[100], contrasenia[100], codigoVuelo[100][50], salida[100][50], input[50];
	int regreso, comprobacion, opcion=0, salir=0, menu=2;
	static int indiceR=0;
	


		if(strcmp(arreglo1,nickname)==0&&vuelo==-1){
			if(strcmp(arreglo2,contrasenia)==0){
				regreso=1;
			}
		}else{
			while(salir==0){	
				switch(vuelo){			
					case 0:
						strcpy(nickname,arreglo1);
						strcpy(contrasenia,arreglo2);
						salir=1;
						//p("\nNickname %s Contrasenia %s\n",nickname,contrasenia); 
					break;
					case -1:
						
						strcpy(codigoVuelo[indiceR],arreglo1);
						strcpy(salida[indiceR],arreglo2);
						salir=1;
						//p("\nCodigo %s salida %s\n",codigoVuelo[indiceR],salida[indiceR]); getchar(); FLUSH CLEAR
						indiceR++; 				
					break;
					default:	
						
						arreglo2=RegresarCadena(codigoVuelo[indiceR-1],vuelo);
						p("\nSe ha pasado come %s**\n",arreglo2);
						salir=1;
						regreso=1;
						
					break;
				}
			}
		}

	
	return regreso;
}
char *RegresarCadena(char arreglo[],int vuelo){

	static char codigo[50];
	if(vuelo!=0){
		codigo[0]='\0';
		strcat(codigo, arreglo);
	p("\nSe recibio %s**\n",codigo);
	}
	
		
	return codigo;

}


